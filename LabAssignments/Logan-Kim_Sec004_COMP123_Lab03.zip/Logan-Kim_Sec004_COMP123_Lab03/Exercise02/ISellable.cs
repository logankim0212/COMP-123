﻿using System;
namespace Exercise02
{
    public interface ISellable
    {
        void SalesSpeech();
        void MakeSale(int value);
    } // end interface
} // end namespace
