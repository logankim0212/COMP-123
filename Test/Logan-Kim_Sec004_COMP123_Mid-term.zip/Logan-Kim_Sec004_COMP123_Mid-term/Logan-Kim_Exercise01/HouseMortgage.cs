﻿using System;

// Logan Kim: 300973239

namespace LoganKim_Exercise01
{
    class HouseMortgage : Mortgage
    {
        // instance data members
        private double propertyTax;
        private double infrastructureTax = 100;

        // Properties
        public double PropertyTax
        {
            get
            {
                return propertyTax;
            } // end get
            set
            {
                if (value > 0)
                {
                    propertyTax = value;
                }
            } // end set
        } // end property

        // Properties
        public double InfrastructureTax
        {
            get
            {
                return infrastructureTax;
            } // end get
            set
            {
                if (value > 0)
                {
                    infrastructureTax = value;
                }
            } // end set
        } // end property

        // Constructor
        public HouseMortgage(int mortgageNumber, string customerName,
                             double mortgageAmount, double yearlyInterestRate,
                             string customerAddress, double propertyTax,
                             double infrastructureTax)
            : base (mortgageNumber, customerName, mortgageAmount,
                    yearlyInterestRate, customerAddress)
        {
            PropertyTax = propertyTax;
            InfrastructureTax = infrastructureTax;
        } // end constructor

        // Method definition
        public override double CalculateMonthlyMortgageInstallment()
        {
            return MortgageAmount * YearlyInterestRate / 12;
        } // end method

        public override string ToString()
        {
            return string.Format("{0} \nProperty Tax: {1:F}% \nInfrastructure " +
                                 "Tax: {2:F}%", base.ToString(), PropertyTax,
                                 InfrastructureTax);
        }
    } // end class
} // end namespace
