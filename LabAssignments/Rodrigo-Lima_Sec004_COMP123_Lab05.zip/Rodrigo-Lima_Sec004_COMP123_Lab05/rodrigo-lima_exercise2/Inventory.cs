﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rodrigo_lima_exercise2
{
    class Inventory
    {
        public int Number { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }
    }
}
